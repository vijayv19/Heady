const express = require('express');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cateogryRouter = require('./routes/cateogry');
const productRouter = require('./routes/product');

const app = express();

mongoose.connect('mongodb://localhost/headyDemo', { useNewUrlParser: true });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
app.use(cookieParser());


// Category Router
app.use('/categoryRoute', cateogryRouter);

// product Router
app.use('/productRoute', productRouter);

/// catch 404 and forwarding to error handler
app.use(function (req, res, next) {
    let err = new Error('Not Found');
    err.status = 404;
    next(err);
});

/// error handlers
// development error handler
if (app.get('env') === 'development') {
    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.json({
            message: err.message,
            error: err
        });
    });
}

// production error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    res.json({ 'Error': err })
    next(err);
});

module.exports = app;
