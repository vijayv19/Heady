const mongoose = require('mongoose');
const categorySchema = mongoose.Schema;

const categoryData = new categorySchema({

    categoryName: String,
    childCategories: [{
        name: String,
        subChildCategories: [{
            name: String
        }]
    }],
    products: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Products'
    }]
});

const categories = mongoose.model('Categories', categoryData);
module.exports = categories;
