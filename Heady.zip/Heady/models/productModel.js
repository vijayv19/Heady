const mongoose = require('mongoose');
const productSchema = mongoose.Schema;

const productData = new productSchema({
    name: String,
    price: Number,
    productCategories: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Categories'
    }]
})
const products = mongoose.model('Products', productData);
module.exports = products;