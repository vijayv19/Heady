const categoryModel = require('../models/categoryModel');
const response = require('../routes/message');


//-Create a new category.
exports.insertCategory = function (req, res) {
    categoryModel.create({
        categoryName: req.body.name,
        childCategories: req.body.childCategories,
        products: req.body.products
    }).then((category) => {
        response.data.responseCode = 200;
        response.data.responseCode = 'Category is created successfully';
        response.data.responseObject = category;
        res.send(response);
    }).catch((err) => {
        if (err) {
            response.data.responseCode = 403;
            response.data.responseMessage = err.message;
            response.data.responseObject = err;
            res.send(response);
        }
    });
};

//-Get Category doc by passing _id.
exports.getCategory = function (req, res) {
    categoryModel.findOne({
        _id: req.body._id
    }).populate('products').then((category) => {
        if (!category) {
            response.data.responseCode = 404;
            response.data.responseCode = 'Records are not found.';
            response.data.responseObject = category;
            res.send(response);
        }
        response.data.responseCode = 200
        response.data.responseCode = 'Category is fetched successfully.'
        response.data.responseObject = category
        res.send(response);
    }).catch((err) => {
        if (err) {
            response.data.responseCode = 403,
                response.data.responseMessage = err.message,
                response.data.responseObject = err
            res.send(response);
        }
    });
};

//-Get all categories with all it's child categories.
exports.getAllCategories = function (req, res) {
    categoryModel.find().populate('products').then((category) => {
        if (!category) {
            response.data.responseCode = 404;
            response.data.responseCode = 'Record is not found';
            response.data.responseObject = category;
            res.send(response);
        }
        response.data.responseCode = 200
        response.data.responseCode = 'Category is fetched successfully'
        response.data.responseObject = category
        res.send(response);
    }).catch((err) => {
        if (err) {
            response.data.responseCode = 403,
                response.data.responseMessage = err.message,
                response.data.responseObject = err
            res.send(response);
        }
    });
};