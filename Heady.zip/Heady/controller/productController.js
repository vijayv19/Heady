const productModel = require('../models/productModel');
const response = require('../routes/message');

//-Create a product to Products collection.
exports.createProduct = function (req, res) {
    productModel.create({
        name: req.body.name,
        price: req.body.price,
        productCategories: req.body.catIds
    }).then((getProduct) => {
        response.data.responseCode = 200;
        response.data.responseMessage = 'Product is created successfully';
        response.data.responseObject = getProduct;
        res.send(response);
    }).catch((err) => {
        if (err) {
            console.log("obj error ", err);
            response.data.responseCode = 403;
            response.data.responseMessage = err.message;
            response.data.responseObject = err;
            res.send(response);
        }
    });
};

//-Get single product
exports.getOneProduct = function (req, res) {
    productModel.findOne({
        _id: req.body._id
    }).populate('productCategories').then((getProduct) => {
        if (!getProduct) {
            response.data.responseCode = 404;
            response.data.responseMessage = 'Product is not found';
            response.data.responseObject = getProduct;
            res.send(response);
        }
        response.data.responseCode = 200;
        response.data.responseMessage = 'Product is fetched successfully';
        response.data.responseObject = getProduct;
        res.send(response);
    }).catch((err) => {
        if (err) {
            console.log("obj error ", err);
            response.data.responseCode = 403;
            response.data.responseMessage = err.message;
            response.data.responseObject = err;
            res.send(response);
        }
    });

};

//-Get all products
exports.getAllProducts = function (req, res) {
    productModel.find().populate('productCategories').then((getProducts) => {
        if (!getProducts) {
            response.data.responseCode = 404;
            response.data.responseMessage = 'Product is not found';
            response.data.responseObject = getProducts;
            res.send(response);
        }
        response.data.responseCode = 200;
        response.data.responseMessage = 'Product is fetched successfully';
        response.data.responseObject = getProducts;
        res.send(response);
    }).catch((err) => {
        if (err) {
            console.log("obj error ", err);
            response.data.responseCode = 403;
            response.data.responseMessage = err.message;
            response.data.responseObject = err;
            res.send(response);
        }
    });

};

//-Update a product passing by _id.
exports.updateProduct = function (req, res) {
    productModel.updateOne({
        _id: req.body.id
    }, {
            $set: {
                name: req.body.prodName,
                price: req.body.price
            }
        }).then((updateProduct) => {
            if (updateProduct.nModified > 0) {
                response.data.responseCode = 200;
                response.data.responseMessage = 'product is updated successfully';
                response.data.responseObject = updateProduct;
                res.send(response);
            }
            response.data.responseCode = 404;
            response.data.responseMessage = 'match condition is not found';
            response.data.responseObject = updateProduct;
            res.send(response);
        }).catch((err) => {
            if (err) {
                console.log("obj error ", err);
                response.data.responseCode = 403;
                response.data.responseMessage = err.message;
                response.data.responseObject = err;
                res.send(response);
            }
        });
};

//- Get All Products by a Category
exports.getAllProductsByCatId = function (req, res) {
    productModel.find({
        productCategories: req.body.catId
    }).populate('productCategories').then((getProductsByCategories) => {
        if (!getProductsByCategories) {
            response.data.responseCode = 404;
            response.data.responseMessage = 'Product is not found by category Id';
            response.data.responseObject = getProductsByCategories;
            res.send(response);
        }
        response.data.responseCode = 200;
        response.data.responseMessage = 'Product is fetched successfully by category Id';
        response.data.responseObject = getProductsByCategories;
        res.send(response);
    }).catch((err) => {
        if (err) {
            console.log("obj error ", err);
            response.data.responseCode = 403;
            response.data.responseMessage = err.message;
            response.data.responseObject = err;
            res.send(response);
        }
    });
};

//-Update productCategories
exports.updateProductCatId = function (req, res) {
    productModel.updateOne({
        _id: req.body.id,
        'productCategories': req.body.catId
    }, {
            $set: {
                'productCategories.$': req.body.newCatId
            }
        }).then((updateProduct) => {
            if (updateProduct.nModified > 0) {
                response.data.responseCode = 200;
                response.data.responseMessage = 'product category is updated successfully';
                response.data.responseObject = updateProduct;
                res.send(response);
            }
            response.data.responseCode = 404;
            response.data.responseMessage = 'match condition is not found';
            response.data.responseObject = updateProduct;
            res.send(response);
        }).catch((err) => {
            if (err) {
                console.log("obj error ", err);
                response.data.responseCode = 403;
                response.data.responseMessage = err.message;
                response.data.responseObject = err;
                res.send(response);
            }
        });
};