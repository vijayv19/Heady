var express = require('express');
var router = express.Router();
var productController = require('../controller/productController');


router.post('/createProduct', productController.createProduct);
router.post('/updateProduct', productController.updateProduct);
router.get('/getAllProductsByCatId', productController.getAllProductsByCatId);
router.get('/getOneProduct', productController.getOneProduct);
router.post('/updateProductCatId', productController.updateProductCatId);
router.get('/getAllProducts', productController.getAllProducts);


module.exports = router;
