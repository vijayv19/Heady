module.exports.data = {
    responseCode: 0,
    responseMessage: '',
    responseObject: {},
}


